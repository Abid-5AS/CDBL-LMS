export { PendingLeaveRequestsTable as PendingApprovals } from "./PendingApprovals";
export { CancellationRequestsPanel as CancellationRequests } from "./CancellationRequests";