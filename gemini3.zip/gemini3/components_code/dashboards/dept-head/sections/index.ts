export { DeptHeadPendingTable as PendingTable } from "./PendingTable";
export { DeptHeadQuickActions as QuickActions } from "./QuickActions";
export { DeptHeadTeamOverview as TeamOverview } from "./TeamOverview";